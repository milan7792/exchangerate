const currencyEl_one = document.getElementById('currency-one');
const amountEl_one = document.getElementById('amount-one');
const currencyEl_two = document.getElementById('currency-two');
const amountEl_two = document.getElementById('amount-two');
const rateEl = document.getElementById('rate');
const swap = document.getElementById('swap');

//  국가 코드 - KR 추가
const getCountryCode = async () => {
  const response = await fetch('https://ipinfo.io/json?token=c76190236a0eea')
  if (response.status === 200) {
    const location = await response.json()
    return location.country
  } else {
    throw new Error('Unable to get your location')
  }
}

//   const getCurrencyCode = async (countryCode) => {
//   const response = await fetch('http://restcountries.com/v3.1/all?access_key=9802a6c810a09b5088cb5da4a7d120aa')
//   if (response.status === 200) {
//     const data = await response.json()
//     const country = data.find((country) => country.alpha2Code === countryCode)
//     return country.currencies[0].code
//   } else {
//     throw new Error('Unable to get the currency code')
//   }
// }

//  기본으로 KRW가 선택되도록
// getCountryCode().then((data) => {
//   return getCurrencyCode(data)
// }).then((data) => {
//   for (i = 0; i < currencyEl_two.options.length; i ++) {
//     if (currencyEl_two.options[i].value === data) {
//       currencyEl_two.options[i].selected = true
//       calculate()
//     }
//   }
// }).catch((err) => {
//   console.log(err)
// })

// //  기준 국가코드와 환산 대상 국가코드를 활용해서 환산 대상 국가의 환율을 출력하는 함수
// const getResultRatesByBaseCode = async (baseCode, resultCode) => {
//   const response = await fetch(`https://api.exchangerate-api.com/v4/latest/${baseCode}`)
//   if (response.status === 200) {
//     const data = await response.json()
//     return data.rates[resultCode]
//   } else {
//     throw new Error('Unable to get the rate')
//   }
// }

// //  통화 계산
// const calculate = async () => {
//   const currency_one = currencyEl_one.value
//   const currency_two = currencyEl_two.value
//   const element_one = amountEl_one.value
//   const element_two = amountEl_two.value

//   const data = await getResultRatesByBaseCode(currency_one, currency_two)
  
//   element_two.value = await (data * amountEl_one.value).toFixed(4)
//   rateEl.innerText = `${amountEl_one.value} ${currency_one} = ${(amountEl_two.value * amountEl_one.value).toFixed(4)} ${currency_two}`
// }

function calculate() {
  const currency_one = currencyEl_one.value;
  const currency_two = currencyEl_two.value;
  fetch("https://open.exchangerate-api.com/v6/latest")  // 국가별 실시간 환율 오픈 API
    .then(res => res.json())
    .then(data => {
      //  console.log(data);
      const rate = data.rates[currency_two] / data.rates[currency_one];
      rateEl.innerText = `1 ${currency_one} = ${rate} ${currency_two}`;
      amountEl_two.value = (amountEl_one.value * (rate)).toFixed(2);
    });
}


// 이벤트 리스너
currencyEl_one.addEventListener('change', calculate);
amountEl_one.addEventListener('input', calculate);
currencyEl_two.addEventListener('change', calculate);
amountEl_two.addEventListener('input', calculate);

swap.addEventListener('click', () => {
  const temp = currencyEl_one.value;
  currencyEl_one.value = currencyEl_two.value;
  currencyEl_two.value = temp;
  calculate();
});


calculate();