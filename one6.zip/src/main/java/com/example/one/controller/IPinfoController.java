package com.example.one.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/ipinfo")
@Api(tags = "IPinfo API")
public class IPinfoController {

    @GetMapping("/latest")
    @ApiOperation(value = "Get latest ip info")
    public String getLatestIpinfo() {
        String apiUrl = "https://ipinfo.io/json?token=c76190236a0eea";

        RestTemplate restTemplate = new RestTemplate();
        String response = restTemplate.getForObject(apiUrl, String.class);

        return response;
    }
}
