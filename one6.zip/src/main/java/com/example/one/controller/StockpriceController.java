package com.example.one.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class StockpriceController {
    public static void main(String[] args) {
        String apiUrl = "https://openapi.koreainvestment.com:9443"; // API 엔드포인트 URL
        String accessToken = "AcvJbexjk3bz9K3V9fnLyw/v1OyZDCa0rpg//zHsjFPuuINrgA6dKRQnXrlYOYC6ic0zdLIkMpp+co6eUj4dEmOxoWd3+4o2DSTqiYX6H5/7yVbwxqXaQdIw/AMaq4Ij3af3UwEPptyi3UmPVagUiDhKWZJPasLG6UCWnmXj1D5J/d5nnOk="; // 발급받은 접근 토큰
        String appKey = "PSLy4gk64wSQPeu947CG26eAbAIfZ4B2f5Oe"; // 발급받은 앱키
        String marketCode = "J"; // FID 조건 시장 분류 코드
        String stockCode = "종목번호"; // 종목번호 (6자리) - ETN의 경우 "Q"로 시작

        try {
            // API 호출을 위한 URL 설정
            String query = String.format("FID_COND_MRKT_DIV_CODE=%s&FID_INPUT_ISCD=%s",
                    URLEncoder.encode(marketCode, "UTF-8"), URLEncoder.encode(stockCode, "UTF-8"));
            apiUrl += "?" + query;

            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);
            conn.setRequestProperty("appkey", appKey);

            // API 호출 및 응답 처리
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                // 응답 데이터 처리
                String responseData = response.toString();
                System.out.println("Response: " + responseData);
            } else {
                System.out.println("API 호출 실패 - 응답코드: " + responseCode);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
