package com.example.one.controller;

import com.example.one.model.SearchResult;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import io.swagger.annotations.Api;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

@RestController
@Api(tags = "Stock API")
@RequestMapping("/stock")
public class StockpriceController {
    private static final String APP_KEY = "PSLy4gk64wSQPeu947CG26eAbAIfZ4B2f5Oe";
    private static final String APP_SECRET = "AcvJbexjk3bz9K3V9fnLyw/v1OyZDCa0rpg//zHsjFPuuINrgA6dKRQnXrlYOYC6ic0zdLIkMpp+co6eUj4dEmOxoWd3+4o2DSTqiYX6H5/7yVbwxqXaQdIw/AMaq4Ij3af3UwEPptyi3UmPVagUiDhKWZJPasLG6UCWnmXj1D5J/d5nnOk=";
    private static String ACCESS_TOKEN = "";

    private Log logger = LogFactory.getLog(this.getClass());

    @GetMapping("/get")
    @ResponseBody
    public String getStock(
            @RequestParam("fid_cond_mrkt_div_code") String fidCondMrktDivCode,
            @RequestParam("fid_input_iscd") String fidInputIscd
    ) throws IOException {
        String url = "https://openapivts.koreainvestment.com:29443/uapi/domestic-stock/v1/quotations/inquire-price";

        HttpHeaders headers = new HttpHeaders();
        headers.set("PSLy4gk64wSQPeu947CG26eAbAIfZ4B2f5Oe", APP_KEY);
        headers.set("AcvJbexjk3bz9K3V9fnLyw/v1OyZDCa0rpg//zHsjFPuuINrgA6dKRQnXrlYOYC6ic0zdLIkMpp+co6eUj4dEmOxoWd3+4o2DSTqiYX6H5/7yVbwxqXaQdIw/AMaq4Ij3af3UwEPptyi3UmPVagUiDhKWZJPasLG6UCWnmXj1D5J/d5nnOk=", APP_SECRET);

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.exchange(
                url, HttpMethod.GET, new HttpEntity<>(headers), String.class);

        String json = responseEntity.getBody();

        ObjectMapper objectMapper = new ObjectMapper();
        ObjectReader objectReader = objectMapper.reader().forType(new TypeReference<SearchResult>() {});
        SearchResult searchResult = objectReader.readValue(json);

        return json;
    }
}
