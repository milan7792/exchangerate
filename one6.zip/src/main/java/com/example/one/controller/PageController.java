package com.example.one.controller;

import com.example.one.model.Color;
import com.example.one.service.MainService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/page")
public class PageController {

    private Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;

    @Autowired
    private MainService mainService;

    @GetMapping("/exchangerate")
    public String exchangeForm() {
        return "exchangerate";
    }

    @PostMapping("/calculate")
    public ModelAndView calculateExchange(@RequestParam double amount, @RequestParam String currency) {

        // 환율 정보를 이용하여 계산 로직 작성
        double exchangeRate = getExchangeRate(currency); // 통화 코드에 해당하는 환율을 가져옴
        double calculatedAmount = amount * exchangeRate; // 환율을 적용한 금액 계산

        Map<String, Object> model = new HashMap<>();
        model.put("amount", amount);
        model.put("currency", currency);
        model.put("calculatedAmount", calculatedAmount);

        return new ModelAndView("exchangerate", model);
    }

    private double getExchangeRate(String currency) {
        // 환율 정보를 가져오는 로직 작성
        // 이 예시에서는 간단히 rates 객체에서 해당 통화 코드의 환율 값을 가져옴
        Map<String, Double> rates = getExchangeRate();
        return rates.get(currency);
    }

    private Map<String, Double> getExchangeRate() {
        // 실제로는 API를 호출하여 환율 정보를 가져오는 로직을 작성해야 합니다.
        // 이 예시에서는 미리 주어진 JSON 응답을 이용하여 환율 정보를 생성하는 가짜 메서드를 사용합니다.
        String json = "{\"result\":\"success\",\"provider\":\"https://open.exchangerate-api.com/v6/latest\",\"documentation\":\"https://open.exchangerate-api.com/v6/latest/docs/free\",\"terms_of_use\":\"https://open.exchangerate-api.com/v6/latest/terms\",\"time_last_update_unix\":1686355352,\"time_last_update_utc\":\"Sat, 10 Jun 2023 00:02:32 +0000\",\"time_next_update_unix\":1686441982,\"time_next_update_utc\":\"Sun, 11 Jun 2023 00:06:22 +0000\",\"time_eol_unix\":0,\"base_code\":\"USD\",\"rates\":{\"USD\":1,\"AED\":3.6725,\"EUR\":0.930072,\"JPY\":139.387697}}";
        // JSON 파싱을 위해 적절한 JSON 라이브러리를 사용해야 합니다. (예: Jackson, Gson 등)
        // 이 예시에서는 간단히 문자열을 직접 처리합니다.
        Map<String, Double> rates = new HashMap<>();
        return rates;
    }
}
