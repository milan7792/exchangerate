package com.example.one.controller;

import com.example.one.model.Object;
import com.example.one.model.SearchResult;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Locale;

@RestController
@RequestMapping("/exchangerate")
@Api(tags = "ExchangeRate API")
public class ExchangerateController {

    @GetMapping("/latest")

    @ApiOperation(value = "Get latest exchange rates")
    public Object getLatestExchangeRates() throws IOException {
        String apiUrl = "https://open.exchangerate-api.com/v6/latest";

        RestTemplate restTemplate = new RestTemplate();
        String response = restTemplate.getForObject(apiUrl, String.class);
        response = response.toLowerCase(Locale.ROOT);
        ObjectMapper objectMapper = new ObjectMapper();

        ObjectReader objectReader = objectMapper.reader().forType(new TypeReference<Object>() {
        });
        Object object = objectReader.readValue(response);
        System.out.println("<option value='usd'> USD </option>");
        System.out.println("<option value='aed'> AED </option>");
        System.out.println("<option value='ars'> ARS </option>");
        System.out.println("<option value='aud'> AUD </option>");
        System.out.println("<option value='bgn'> BGN </option>");
        System.out.println("<option value='brl'> BRL </option>");
        System.out.println("<option value='cad'> CAD </option>");
        System.out.println("<option value='chf'> CHF </option>");
        System.out.println("<option value='clp'> CLP </option>");
        System.out.println("<option value='cny'> CNY </option>");
        System.out.println("<option value='cop'> COP </option>");
        System.out.println("<option value='czk'> CZK </option>");
        System.out.println("<option value='dop'> DOP </option>");
        System.out.println("<option value='egp'> EGP </option>");
        System.out.println("<option value='eur'> EUR </option>");
        System.out.println("<option value='fjd'> FJD </option>");
        System.out.println("<option value='aed'> AED </option>");
        System.out.println("<option value='gbp'> GBP </option>");
        System.out.println("<option value='czk'> CZK </option>");
        System.out.println("<option value='gtq'> GTQ </option>");
        System.out.println("<option value='hkd'> HKD </option>");
        System.out.println("<option value='hrk'> HRK </option>");
        System.out.println("<option value='huf'> HUF </option>");
        System.out.println("<option value='idr'> IDR </option>");
        System.out.println("<option value='ils'> ILS </option>");
        System.out.println("<option value='czk'> CZK </option>");
        System.out.println("<option value='inr'> INR </option>");
        System.out.println("<option value='isk'> ISK </option>");
        System.out.println("<option value='kzt'> KZT </option>");
        System.out.println("<option value='czk'> CZK </option>");
        System.out.println("<option value='mxn'> MXN </option>");
        System.out.println("<option value='czk'> CZK </option>");
        System.out.println("<option value='myr'> MYR </option>");
        System.out.println("<option value='nok'> NOK </option>");
        System.out.println("<option value='nzd'> NZD </option>");
        System.out.println("<option value='pen'> PEN </option>");
        System.out.println("<option value='php'> PHP </option>");
        System.out.println("<option value='pkr'> PKR </option>");
        System.out.println("<option value='pln'> PLN </option>");
        System.out.println("<option value='pyg'> PYG </option>");
        System.out.println("<option value='ron'> RON </option>");
        System.out.println("<option value='rub'> RUB </option>");
        System.out.println("<option value='sar'> SAR </option>");
        System.out.println("<option value='sek'> SEK </option>");
        System.out.println("<option value='sgd'> SGD </option>");
        System.out.println("<option value='thb'> THB </option>");
        System.out.println("<option value='twd'> TWD </option>");
        System.out.println("<option value='czk'> CZK </option>");
        System.out.println("<option value='uah'> UAH </option>");
        System.out.println("<option value='uyu'> UYU </option>");
        System.out.println("<option value='czk'> CZK </option>");
        System.out.println("<option value='vnd'> VND </option>");
        System.out.println("<option value='czk'> CZK </option>");
        System.out.println("<option value='zar'> ZAR </option>");
        System.out.println("<option value='krw'> KRW </option>");
        System.out.println("<option value='jpy'> JPY </option>");

        return object;
    }
}
