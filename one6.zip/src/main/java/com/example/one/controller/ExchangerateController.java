package com.example.one.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/exchangerate")
@Api(tags = "ExchangeRate API")
public class ExchangerateController {

    @GetMapping("/latest")
    @ApiOperation(value = "Get latest exchange rates")
    public String getLatestExchangeRates() {
        String apiUrl = "https://open.exchangerate-api.com/v6/latest";

        RestTemplate restTemplate = new RestTemplate();
        String response = restTemplate.getForObject(apiUrl, String.class);

        return response;
    }
}
