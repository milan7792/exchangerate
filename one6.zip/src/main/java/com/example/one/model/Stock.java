package com.example.one.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Stock {
    private String iscd_stat_cls_code;  // 종목 상태 구분 코드
    private String rprs_mrkt_kor_name;  // 대표 시장 한글명
    private String bstp_kor_isnm;   // 업종 한글 종목명
    private String stck_prpr;   // 주식 현재가
    private String prdy_vrss;   // 전일 대비
    private String prdy_vrss_sign;  // 전일 대비 부호
    private String prdy_ctrt;   // 전일 대비율
    private String acml_tr_pbmn;    // 누적 거래 대금
    private String acml_vol;    // 누적 거래량
    private String stck_oprc;   // 주식 시가
    private String stck_hgpr;   // 주식 최고가
    private String stck_lwpr;   // 주식 최저가
    private String stck_mxpr;   // 주식 상한가
    private String stck_llam;   // 주식 하한가
    private String stck_sdpr;   // 주식 기준가
}
