package com.example.one.dashin.cptrade.events;

import com4j.*;

/**
 * _ITdDibEvents Interface
 */
@IID("{8B55AD34-73A3-4C33-B8CD-C95ED13823CB}")
public abstract class _ITdDibEvents {
  // Methods:
  /**
   * <p>
   * method Received
   * </p>
   */

  @DISPID(1)
  public void received() {
        throw new UnsupportedOperationException();
  }


  // Properties:
}
