package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_BOND_ISSUE {
  /**
   * <p>
   * ��ü
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_BOND_ALL_ISSUE, // 0
  /**
   * <p>
   * ��������1��
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_BOND_NATIONHOUSING1_ISSUE, // 1
  /**
   * <p>
   * ��������2��
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  CPC_BOND_NATIONHOUSING2_ISSUE, // 2
  /**
   * <p>
   * ��������3��
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  CPC_BOND_NATIONHOUSING3_ISSUE, // 3
  /**
   * <p>
   * ��ä
   * </p>
   * <p>
   * The value of this constant is 4
   * </p>
   */
  CPC_BOND_GOVERNMENT_ISSUE, // 4
  /**
   * <p>
   * ���ﵵ��ö��ä��
   * </p>
   * <p>
   * The value of this constant is 5
   * </p>
   */
  CPC_BOND_SEOULRAILROAD_ISSUE, // 5
  /**
   * <p>
   * ��������ä
   * </p>
   * <p>
   * The value of this constant is 6
   * </p>
   */
  CPC_BOND_REGIONDEVELOP_ISSUE, // 6
  /**
   * <p>
   * ���浵��ö��/�λ걳
   * </p>
   * <p>
   * The value of this constant is 7
   * </p>
   */
  CPC_BOND_COUNTRYRAILROAD_ISSUE, // 7
  /**
   * <p>
   * ��Ÿ����ä
   * </p>
   * <p>
   * The value of this constant is 8
   * </p>
   */
  CPC_BOND_OTHERMUNICIPAL_ISSUE, // 8
  /**
   * <p>
   * ��������ä
   * </p>
   * <p>
   * The value of this constant is 9
   * </p>
   */
  CPC_BOND_ESTATEDEVELOP_ISSUE, // 9
  /**
   * <p>
   * �ѱ����°���
   * </p>
   * <p>
   * The value of this constant is 10
   * </p>
   */
  CPC_BOND_KRELECTRIC_ISSUE, // 10
  /**
   * <p>
   * ��ŸƯ��ä
   * </p>
   * <p>
   * The value of this constant is 11
   * </p>
   */
  CPC_BOND_OTHERSPECIFIC_ISSUE, // 11
  /**
   * <p>
   * ����ä
   * </p>
   * <p>
   * The value of this constant is 12
   * </p>
   */
  CPC_BOND_FINANCIAL_ISSUE, // 12
  /**
   * <p>
   * ���ä
   * </p>
   * <p>
   * The value of this constant is 13
   * </p>
   */
  CPC_BOND_CURRENCY_ISSUE, // 13
  /**
   * <p>
   * ȸ��ä
   * </p>
   * <p>
   * The value of this constant is 14
   * </p>
   */
  CPC_BOND_CORPORATE_ISSUE, // 14
  /**
   * <p>
   * �ֽİ��û�ä
   * </p>
   * <p>
   * The value of this constant is 15
   * </p>
   */
  CPC_BOND_STOCK_ISSUE, // 15
}
