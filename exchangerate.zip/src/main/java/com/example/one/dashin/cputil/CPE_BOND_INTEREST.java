package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_BOND_INTEREST {
  /**
   * <p>
   * ��ü
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_BOND_ALL_INTEREST, // 0
  /**
   * <p>
   * ����ä
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_BOND_DISCOUNT_INTEREST, // 1
  /**
   * <p>
   * �ܸ�ä
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  CPC_BOND_SIMPLE_INTEREST, // 2
  /**
   * <p>
   * ����ä
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  CPC_BOND_COMPOUND_INTEREST, // 3
  /**
   * <p>
   * ��ǥä
   * </p>
   * <p>
   * The value of this constant is 4
   * </p>
   */
  CPC_BOND_COUPON_INTEREST, // 4
  /**
   * <p>
   * ���ݺ���
   * </p>
   * <p>
   * The value of this constant is 5
   * </p>
   */
  CPC_BOND_DIVISION_INTEREST, // 5
}
