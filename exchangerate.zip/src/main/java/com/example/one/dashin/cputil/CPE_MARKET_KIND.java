package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_MARKET_KIND {
  /**
   * <p>
   * ���о���
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_MARKET_NULL, // 0
  /**
   * <p>
   * �ŷ���
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_MARKET_KOSPI, // 1
  /**
   * <p>
   * �ڽ���
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  CPC_MARKET_KOSDAQ, // 2
  /**
   * <p>
   * K-OTC
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  CPC_MARKET_FREEBOARD, // 3
  /**
   * <p>
   * KRX
   * </p>
   * <p>
   * The value of this constant is 4
   * </p>
   */
  CPC_MARKET_KRX, // 4
  /**
   * <p>
   * KONEX
   * </p>
   * <p>
   * The value of this constant is 5
   * </p>
   */
  CPC_MARKET_KONEX, // 5
}
