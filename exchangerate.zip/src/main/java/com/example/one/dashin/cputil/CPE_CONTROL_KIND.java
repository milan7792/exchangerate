package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_CONTROL_KIND {
  /**
   * <p>
   * ����
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_CONTROL_NONE, // 0
  /**
   * <p>
   * ����
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_CONTROL_ATTENTION, // 1
  /**
   * <p>
   * ���
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  CPC_CONTROL_WARNING, // 2
  /**
   * <p>
   * ���迹��
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  CPC_CONTROL_DANGER_NOTICE, // 3
  /**
   * <p>
   * ����
   * </p>
   * <p>
   * The value of this constant is 4
   * </p>
   */
  CPC_CONTROL_DANGER, // 4
  /**
   * <p>
   * �����
   * </p>
   * <p>
   * The value of this constant is 5
   * </p>
   */
  CPC_CONTROL_WARNING_NOTICE, // 5
}
