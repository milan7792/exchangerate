package com.example.one.dashin.cpsysdib.events;

import com4j.*;

/**
 * _ISysDibEvents Interface
 */
@IID("{60D7702A-57BA-4869-AF3F-292FDC909D75}")
public abstract class _ISysDibEvents {
  // Methods:
  /**
   * <p>
   * method Received
   * </p>
   */

  @DISPID(1)
  public void received() {
        throw new UnsupportedOperationException();
  }


  // Properties:
}
