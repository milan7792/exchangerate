package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_STOCK_STATUS_KIND {
  /**
   * <p>
   * ����
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_STOCK_STATUS_NORMAL, // 0
  /**
   * <p>
   * �ŷ�����
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_STOCK_STATUS_STOP, // 1
  /**
   * <p>
   * �ŷ��ߴ�
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  CPC_STOCK_STATUS_BREAK, // 2
}
