package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_BOND_REMAIN {
  /**
   * <p>
   * ������
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_BOND_REMAIN_NONE, // 0
  /**
   * <p>
   * ��������
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_BOND_REMAIN, // 1
}
