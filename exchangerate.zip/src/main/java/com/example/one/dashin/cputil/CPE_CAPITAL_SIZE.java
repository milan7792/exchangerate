package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_CAPITAL_SIZE {
  /**
   * <p>
   * ����
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_CAPITAL_NULL, // 0
  /**
   * <p>
   * ��
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_CAPITAL_LARGE, // 1
  /**
   * <p>
   * ��
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  CPC_CAPITAL_MIDDLE, // 2
  /**
   * <p>
   * ��
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  CPC_CAPITAL_SMALL, // 3
}
