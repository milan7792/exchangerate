package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_KOSPI200_KIND {
  /**
   * <p>
   * ��ä��
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_KOSPI200_NONE, // 0
  /**
   * <p>
   * �Ǽ�
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_KOSPI200_MANUFACTURE, // 1
  /**
   * <p>
   * �߰���
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  CPC_KOSPI200_SHIP, // 2
  /**
   * <p>
   * ö������
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  CPC_KOSPI200_IRON, // 3
  /**
   * <p>
   * ������ȭ��
   * </p>
   * <p>
   * The value of this constant is 4
   * </p>
   */
  CPC_KOSPI200_ENERGY, // 4
  /**
   * <p>
   * �������
   * </p>
   * <p>
   * The value of this constant is 5
   * </p>
   */
  CPC_KOSPI200_INFO, // 5
  /**
   * <p>
   * ����
   * </p>
   * <p>
   * The value of this constant is 6
   * </p>
   */
  CPC_KOSPI200_FINANCE, // 6
  /**
   * <p>
   * �ʼ��Һ���
   * </p>
   * <p>
   * The value of this constant is 7
   * </p>
   */
  CPC_KOSPI200_NEC_CONS, // 7
  /**
   * <p>
   * �����Һ���
   * </p>
   * <p>
   * The value of this constant is 8
   * </p>
   */
  CPC_KOSPI200_FREE_CONS, // 8
  /**
   * <p>
   * �����
   * </p>
   * <p>
   * The value of this constant is 9
   * </p>
   */
  CPC_KOSPI200_INDUSTRY_CONS, // 9
  /**
   * <p>
   * �ǰ�����
   * </p>
   * <p>
   * The value of this constant is 10
   * </p>
   */
  CPC_KOSPI200_HEALTHCARE, // 10
  /**
   * <p>
   * Ŀ�´����̼�
   * </p>
   * <p>
   * The value of this constant is 11
   * </p>
   */
  CPC_KOSPI200_COMMUNICATION, // 11
}
