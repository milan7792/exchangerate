package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_KSE_SECTION_KIND_OLD {
  /**
   * <p>
   * ���о���
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_KSE_SECTION_NULL, // 0
  /**
   * <p>
   * 1��
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_KSE_SECTION_1, // 1
  /**
   * <p>
   * 2��
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  CPC_KSE_SECTION_2, // 2
  /**
   * <p>
   * �ֽĿ�Ź����
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  CPC_KSE_SECTION_DR, // 3
  /**
   * <p>
   * ����ȸ��
   * </p>
   * <p>
   * The value of this constant is 4
   * </p>
   */
  CPC_KSE_SECTION_IC, // 4
  /**
   * <p>
   * �����μ�������
   * </p>
   * <p>
   * The value of this constant is 5
   * </p>
   */
  CPC_KSE_SECTION_WR, // 5
  /**
   * <p>
   * ����
   * </p>
   * <p>
   * The value of this constant is 6
   * </p>
   */
  CPC_KSE_SECTION_REITS, // 6
  /**
   * <p>
   * �����μ�������
   * </p>
   * <p>
   * The value of this constant is 7
   * </p>
   */
  CPC_KSE_SECTION_RIGHT, // 7
  /**
   * <p>
   * ETF
   * </p>
   * <p>
   * The value of this constant is 8
   * </p>
   */
  CPC_KSE_SECTION_ETF, // 8
  /**
   * <p>
   * ��������
   * </p>
   * <p>
   * The value of this constant is 9
   * </p>
   */
  CPC_KSE_SECTION_BC, // 9
  /**
   * <p>
   * ��������ȸ��
   * </p>
   * <p>
   * The value of this constant is 10
   * </p>
   */
  CPC_KSE_SECTION_SIC, // 10
  /**
   * <p>
   * ELW
   * </p>
   * <p>
   * The value of this constant is 11
   * </p>
   */
  CPC_KSE_SECTION_ELW, // 11
  /**
   * <p>
   * ������������ȸ��
   * </p>
   * <p>
   * The value of this constant is 12
   * </p>
   */
  CPC_KSE_SECTION_INFRA, // 12
  /**
   * <p>
   * �ؿ�ETF
   * </p>
   * <p>
   * The value of this constant is 13
   * </p>
   */
  CPC_KSE_SECTION_FOREIGN_ETF, // 13
  /**
   * <p>
   * �ؿܿ���
   * </p>
   * <p>
   * The value of this constant is 14
   * </p>
   */
  CPC_KSE_SECTION_FOREIGN, // 14
}
