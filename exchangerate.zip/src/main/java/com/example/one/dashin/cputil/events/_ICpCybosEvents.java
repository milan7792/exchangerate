package com.example.one.dashin.cputil.events;

import com4j.*;

/**
 * _ICpCybosEvents Interface
 */
@IID("{17F70631-56E5-40FC-B94F-44ADD3A850B1}")
public abstract class _ICpCybosEvents {
  // Methods:
  /**
   * <p>
   * method OnDisconnect
   * </p>
   */

  @DISPID(1)
  public void onDisconnect() {
        throw new UnsupportedOperationException();
  }


  // Properties:
}
