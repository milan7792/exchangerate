package com.example.one.dashin.cpdib.events;

import com4j.*;

/**
 * _IDibEvents Interface
 */
@IID("{B8944520-09C3-11D4-8232-00105A7C4F8C}")
public abstract class _IDibEvents {
  // Methods:
  /**
   * <p>
   * method Received
   * </p>
   */

  @DISPID(1)
  public void received() {
        throw new UnsupportedOperationException();
  }


  // Properties:
}
