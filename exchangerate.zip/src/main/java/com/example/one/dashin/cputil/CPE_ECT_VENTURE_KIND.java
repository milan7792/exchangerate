package com.example.one.dashin.cputil;

import com4j.*;

/**
 */
public enum CPE_ECT_VENTURE_KIND {
  /**
   * <p>
   * �Ϲ�
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  CPC_VENTURE_NONE, // 0
  /**
   * <p>
   * ���ı��
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  CPC_VENTURE_NORMAL, // 1
  /**
   * <p>
   * ��ũ����ũ-�Ϲ�
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  CPC_VENTURE_TECHNOPARK_NONE, // 2
  /**
   * <p>
   * ��ũ����ũ-��ó
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  CPC_VENTURE_TECHNOPARK, // 3
  /**
   * <p>
   * �췮�����
   * </p>
   * <p>
   * The value of this constant is 4
   * </p>
   */
  CPC_VENTURE_KOSDAQ_AGRADE, // 4
  /**
   * <p>
   * ��ó�����
   * </p>
   * <p>
   * The value of this constant is 5
   * </p>
   */
  CPC_VENTURE_KOSDAQ_VENTURE, // 5
  /**
   * <p>
   * �߰߱����
   * </p>
   * <p>
   * The value of this constant is 6
   * </p>
   */
  CPC_VENTURE_KOSDAQ_MIDDLE, // 6
  /**
   * <p>
   * �ż�������
   * </p>
   * <p>
   * The value of this constant is 7
   * </p>
   */
  CPC_VENTURE_KOSDAQ_NEWGROWTH, // 7
  /**
   * <p>
   * �ܱ����
   * </p>
   * <p>
   * The value of this constant is 8
   * </p>
   */
  CPC_VENTURE_KOSDAQ_FOR, // 8
  /**
   * <p>
   * ����ȸ��
   * </p>
   * <p>
   * The value of this constant is 9
   * </p>
   */
  CPC_VENTURE_KOSDAQ_INVEST, // 9
  /**
   * <p>
   * SPAC
   * </p>
   * <p>
   * The value of this constant is 10
   * </p>
   */
  CPC_VENTURE_KOSDAQ_SPACE, // 10
  /**
   * <p>
   * ETF
   * </p>
   * <p>
   * The value of this constant is 11
   * </p>
   */
  CPC_VENTURE_KOSDAQ_ETF, // 11
  /**
   * <p>
   * ��������
   * </p>
   * <p>
   * The value of this constant is 12
   * </p>
   */
  CPC_VENTURE_KOSDAQ_BANKRUP, // 12
  /**
   * <p>
   * ����ȯ������
   * </p>
   * <p>
   * The value of this constant is 13
   * </p>
   */
  CPC_VENTURE_KOSDAQ_DANGER, // 13
  /**
   * <p>
   * ��Ÿ
   * </p>
   * <p>
   * The value of this constant is 14
   * </p>
   */
  CPC_VENTURE_KOSDAQ_ETC, // 14
}
